import styled from 'styled-components';

const Wrapper = styled.div`
  margin-top: 15px;
  text-align: center;
`;

export default Wrapper;